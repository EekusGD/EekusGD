import time
for i in range(100):
    speed = str(i + 1) #speed format
    location = "russia" #locationVPN
    print(speed + "%" + location) #speed
    time.sleep(0.1) #speed counter