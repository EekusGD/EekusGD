put me in res and then update the app

This mod adds a faster loading animation and adds more offset after an ad. If someone needs this, download it.